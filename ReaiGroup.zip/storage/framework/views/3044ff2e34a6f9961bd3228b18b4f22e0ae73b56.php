<aside class="control-sidebar control-sidebar-<?php echo e(config('adminlte.right_sidebar_theme')); ?>">
    <?php echo $__env->yieldContent('right-sidebar'); ?>
</aside>
<?php /**PATH C:\Users\PC bre\Desktop\ReaiGroupLaravel\ReaiGroup\vendor\jeroennoten\laravel-adminlte\src/../resources/views/partials/sidebar/right-sidebar.blade.php ENDPATH**/ ?>